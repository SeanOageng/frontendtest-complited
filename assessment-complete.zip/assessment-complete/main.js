/* global $ */

const showData = () => {
  $.ajax({
    url: 'https://randomuser.me/api/',
    dataType: 'json',
    success: (data) => {
      const { name, registered, dob, email, phone, location, picture, login } = data.results[0]
      
      const parsedRegDate = registered.date.split(' ')[0].split('-').join('/')
      var n=new Date(dob.date);
    
      


      $('.intro-text').text('Hi, my name is')
      $('.dynamic-slot').text(name.first + ' ' + name.last)   

      $(".profile").hover(
        function ()
        {   
          $('.intro-text').text('Hi, my name is')
          $('.dynamic-slot').text(name.first + ' ' + name.last)          
        });

      $(".email").hover(
          function ()
          {
            $('.intro-text').text('My email address is')
            $('.dynamic-slot').text(email)
        });
      
      $(".dob").hover(
          function ()
          {
            $('.intro-text').text('My birthday is')
            // $('.dynamic-slot').text(parsedDateBirth)
            
            $('.dynamic-slot').text(n.getMonth()+1+"/"+(n.getDay()+1)+"/19"+n.getYear())
          });
        
      $(".address").hover(
          function ()
          {
            $('.intro-text').text('My address is')
            $('.dynamic-slot').text(location.street.number +' '+ location.street.name + ',' + location.city + ',' + location.state + ',' + location.postcode )
          });

      $(".tel").hover(
          function ()
          {  
            $('.intro-text').text('My phone number is')
            $('.dynamic-slot').text(phone)
          });

      $(".pass").hover(
          function ()
          {  
            $('.intro-text').text('My password is')
            $('.dynamic-slot').text(login.password)
          });

      $('.profile-image').attr('src', picture.large)
    }
  })
}

showData()

$('#button').on('click', (e) => {
  showData()
})
