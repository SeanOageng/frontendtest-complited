# [RandomUser Generator](https://jalbertsr.github.io/random-user/)


![card user](https://thumb.gyazo.com/thumb/406_w/_debd0b489d0482668f5b404f83c9c4cd-gif)

Resources:
- https://randomuser.me
- http://flag-icon-css.lip.is/
